library("shiny")
library("ggplot2")
library("dplyr")
library("randomForest")
library("shinythemes")
#install.packages("rsconnect")
library("rsconnect")
#rsconnect::setAccountInfo(name='ppuneeth', token='FA884B0E7A940E5200E1154EB3A2C66D', secret='/izpS85SSjyePiji3tSNfKsJE54+Mkgl8wxsLRQh')
#rsconnect::deployApp('C:/Users/puneeth/Documents/class')
imdb <- read.csv("movie_metadata.csv", stringsAsFactors = FALSE)
imdb$grosscat<-cut(imdb$gross, c(0,3000000,35000000,800000000),labels=c("bad","Avg","Good"))
imdb2<-imdb[c('director_facebook_likes','title_year','num_voted_users','grosscat','duration','num_critic_for_reviews','num_user_for_reviews','actor_3_facebook_likes','actor_1_facebook_likes','cast_total_facebook_likes','budget','actor_2_facebook_likes','imdb_score','movie_facebook_likes')]
imdb3<-imdb[c('director_facebook_likes','title_year','num_voted_users','duration','language','num_critic_for_reviews','num_user_for_reviews','actor_3_facebook_likes','actor_1_facebook_likes','gross','cast_total_facebook_likes','budget','actor_2_facebook_likes','imdb_score','movie_facebook_likes')]
imdb2<-na.omit(imdb2)


model <- randomForest(grosscat ~ ., data = imdb2)

# #set.seed(101)
# # Now Selecting 75% of data as sample from total 'n' rows of the data  
#sample <- sample.int(n = nrow(imdb2), size = floor(.75*nrow(imdb2)), replace = F)
#train <- imdb2[sample, ]
#test  <- imdb2[-sample, ]
#print (str(train))
ui <- fluidPage(theme = shinytheme("flatly"),
  navbarPage("IMDB",
    tabPanel("Classification",
  titlePanel("IMDB Data Set(Classification Problem)"),
  sidebarLayout(
    sidebarPanel(
      sliderInput("year", "title year", min = 1920, max = 2020,
                  value = 2016),
      sliderInput("vu", "voted users", min = 0, max = 1689764,
                  value = 10000, pre = "users"),
      sliderInput("dur", "duration", min = 1, max = 300,
                  value = 120, pre = "time in min"),
      textInput("lan", "language", value = "english", width = NULL, placeholder = NULL),
      # sliderInput("gross", "Gross", min = 1000, max = 700000000,
      #             value = 10000, pre = "$"),
      sliderInput("nocr", "critic reviews", min = 1000, max = 700000,
                  value = 100),
      numericInput("dfl", "dir fb likes", min = 1000, max = 600000, step = NA,value=100,
                   width = NULL),
      numericInput("onefb", "actor1 fb likes", min = 1000, max = 600000, step = NA,value=100,
                   width = NULL),
      numericInput("twofb", "actor2 fb likes", min = 1000, max = 600000, step = NA,value=100,
                   width = NULL),
      sliderInput("threefb", "actor3 fb likes", min = 1000, max = 700000,
                  value = 120),
      sliderInput("mfb", "movie fb likes", min = 1000, max = 700000,
                  value = 100),
      numericInput("cfb", "cast fb likes", min = 1000, max = 600000, step = NA,value=100,
                   width = NULL),
      sliderInput("imdb", "imdb rating", min = 1, max = 10,
                  value = 5),
      numericInput("bud", "budget", min = 1000, max = 600000, step = NA,value=100,
                   width = NULL),
      sliderInput("nour", "user reviews", min = 1000, max = 700000000,
                  value = 100)
      #textInput("grsscat", "grosscat", value = "avg", width = NULL, placeholder = NULL)
      #actionButton("classify", "classify")
    ),
    mainPanel(h3("Enter the required values and the gross category
              1-5 range",br(),br(),"The Entered values are"),
      #imageOutput("img"),
      textOutput(("ent")),
      uiOutput(("gc")),
      plotOutput("graph"),br(),br(),
      
      plotOutput("graph2"),
      tableOutput("tab")
      # plotOutput("coolplot"),
      # br(),br(),
      # tableOutput("results")
    )
  )
)
)
#tabPanel("visualization")
)
server <- function(input, output) {
 # filt<-reactive({pred})
  # observeEvent(input$classify,{
  #   model <- randomForest(grosscat ~ ., data = train)
  #   df1<-c(input$dfl,input$year,input$vu,input$dur,input$lan,input$nocr,input$nur,input$threefb,input$onefb,input$gross,input$cfb,input$budget,input$twofb,input$imdb,input$mfb,input$grsscat)
  #   df<-data.frame(df1)
  #   #print(str(df))
  #   names(df)<-c('director_facebook_likes','title_year','num_voted_users','duration','language','num_critic_for_reviews','num_user_for_reviews','actor_3_facebook_likes','actor_1_facebook_likes','gross','cast_total_facebook_likes','budget','actor_2_facebook_likes','imdb_score','movie_facebook_likes','grosscat')
  #   pred <- predict(model, newdata = df)
  # })
 # imdb <- read.csv("movie_metadata.csv", stringsAsFactors = FALSE)
  #pred_tag <- reactive(label_val="")
  output$ent<-renderText({(c(input$dfl,input$year,input$vu,input$dur,input$lan,input$nocr,input$nour,input$threefb,input$onefb,input$cfb,input$bud,input$twofb,input$imdb,input$mfb))})
  output$gc <- renderUI({
    #paste(imdb2)
    
    df1<-c(input$dfl,input$year,input$vu,input$dur,input$lan,input$nocr,input$nour,input$threefb,input$onefb,input$cfb,input$bud,input$twofb,input$imdb,input$mfb)
    df<-data.frame(input$dfl,input$year,input$vu,input$dur,input$lan,input$nocr,input$nour,input$threefb,input$onefb,input$cfb,input$bud,input$twofb,input$imdb,input$mfb)
    #paste("You have selected", input$lan)
    #df<-data.frame(df1)
    #print(str(df))
   names(df)<-c('director_facebook_likes','title_year','num_voted_users','duration','language','num_critic_for_reviews','num_user_for_reviews','actor_3_facebook_likes','actor_1_facebook_likes','cast_total_facebook_likes','budget','actor_2_facebook_likes','imdb_score','movie_facebook_likes')
   p <- predict(model, newdata = df)
   #paste("The predicted gross category is",df,df1)
   tagList(
     c("The predicted gross value is"),
     br(),
     tags$strong(p)
   )
    
   br()
    tags$strong("The predicted gross value is",p)
    #paste("The Predicted Value is",pred)
  })
  output$graph<-renderPlot({
    #ggplot(data=imdb2,aes(x=grosscat,y=gross,color=grosscat))+geom_jitter()
    qplot(imdb3$gross, geom="histogram",xlim=c(1000,4000000))
    #ggplot(imdb2)+geom_histogram(aes(grosscat))
    #ggplot(data=imdb2,aes(y=gross))+geom_histogram()
  })
  output$graph2<-renderPlot({
    ggplot(data=imdb,aes(x=grosscat,y=gross,color=grosscat))+geom_jitter()
  })
  # output$tab2<-renderTable({
  #   df
  # })
  output$tab<-renderTable({
    head(na.omit(imdb3),10)
  })
  # output$img<-renderImage({
  #   list(src = "https://cdn.theunlockr.com/wp-content/uploads/2012/04/IMDb.jpg",
  #        contentType = 'jpg'
  #        )
         #alt = "This is image alternate text")
    
  #})
}
shinyApp(ui = ui, server = server)