I implemented the above classification problem in two phases one in jupyter notebook and other in R shiny using Rstudio.

The required folder is Rshinyapp. I included the jupyter folder for just reference purposes.