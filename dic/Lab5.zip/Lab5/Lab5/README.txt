######################################################################
				Lab 5
#######################################################################

This lab is done in a group of 2  

PARTICIPANTS NAME 	UBIT_NAME	UB_PERSON_NUMBER
Puneeth Pepalla		puneethp		50206906
Arun Sharma		arunshar		50206920

######################################################################
				Environment
#######################################################################
Jupyter Notebok: spark with python2 version
OS: Ubuntu Virtual Machine
Memory : 16 GB 1867 MHz DDR3 
Processor : 2.7 GHz Intel Core i5


######################################################################
				Description
#######################################################################

There are 2 folders in Activity 1 and 2, a plot.png file and a times.csv file (which are both in main folder and the Activity 2 folder). The activities are performed on jupyter notebook using VM provided for this Lab. Details are as follows:

Activity 1 : Simple vignette for using pyspark on titanic dataset and applied Decision Tree and Logistic regression classifier with sigmoid function. We learned various features of pyspark and it's in memory computation power as compared to hdfs.

Activity 2: In this activity we compute word cooccurance using 2 grams and 3 grams using Spark. Here we followed the algorithm provided in the docs i.e. we compared each and every word of the line with it's lemma, if the lemma exist then we emit the words with it's corresponding location, else we emit the normalized words. 
Before applying the algorithm we normalized the word by removing stopwords and punctuations.

The steps of how to run the notebooks are as follows:

#######################################################################
				Activity 1
#######################################################################
There is one input file titanic.csv and one python file Vignette.ipynb.

Step 1 : Just run each and every cell by giving the appropriate path for input.

#######################################################################
				Activity 2
#######################################################################
There are 2 folders (2 grams and 3grams) , csv output and a plot image as described before. Both 2 grams and 3 grams have 3 folders having Input, Output and Code folder.

Input Folder : Contains test latin folder (having only one input file) and a lemmatizer.csv for comparing the lemma. 
Output Folder : Contains output file after processing in the form of key value pair where keys are word pairs and values are their respective locations. 
Code : Contains ipython notebook.

Step 1 : Just run each and every cell by giving the appropriate path for input.


#######################################################################
				Output
#######################################################################
Output format is shown below:

Bigrams
[word1, wor2]  <Loc1>,<loc2>,<loc3>���..
(u'lucius', u'gaius')   <verg. aen. 2.182.1> <verg. aen. 5.57.0> <verg. aen. 2.271.1> 

Trigrams
[word1,word2,word3] <loc1>,<loc2>,<loc3>����
(u'sum', u'ab', u'gaius')    <verg. aen. 2.239> <verg. aen.2.293>
Location=Loc<doc id, para,line >

Performance table
files	2-grams		3-grams
5	22.458	       	29.457
10	32.135		36.342
15	35.365		42.894
20	40.234		55.763
25	46.874		51.587
30	63.543		74.237
35	69.436		69.982
40	68.235		80.154

Performance table above the behaviour of 2 grams and 3 grams of time with respect to number of docs (which are sorted by size in increasing order).
As we can see the 3 grams is not as scalable as compared to 2 grams and the system was unable to process further docs due to memory bound.

The performance graph plot is attached named plot.png which shows the linear behaviours as suggested in the times.csv file which is the Performace Table as discussed earlier.






