lab 4:
Submission:There are 4 folders-> part1,part2,Activity 1,Activity2a,Activity2b
Each Folder contains another 4 subfolders -> jar,javacode,inputs,outputs of their respective parts.
Note: A Seperate readme file is placed in each part of the project for easier understanding.

Part 1:
(The R notebooks for this part are stored in notebooks folder lab4part1 and wordcloud)
1.The notebook "lab4part1" is the r script for crawling tweets.This generates two csv files tweets.csv and final.csv,after removing stopwords and cleaning the tweets the tweets are stored into "final.csv".
2.This final.csv is given as input for hadoop WordCount.jar in the jar/WordCount.jar and rename the output file from hadoop as "ip" without any extension.(I read the file using "\t" as seperator)
3.This "ip" is given as input to wordcloud.ipynb and it generates the wordcloud.

Commands Used in Hadoop:
hadoop jar WordCount.jar WordCount input output


Part 2:
1.part1/jar/WordCount.jar is the jar file to perform normal wordcount.
2.part2/jar/pairs2.jar is the jar file to calculate cooccurance of pairs of words using pairs approach taking one total line as scope.
3.part2/jar/Stripes2.jar is the jar file to find cooccurance using stripes approach.
4.The file part2/input/tweets.csv is given as an input for Stripes and pairs.
5.The outputs I obtained for the pairs and stripes is in the outputs/output_pairs folder and output/output_stripes folder for both tweets and books folder in hadoop.

Hadoop Commands used:
Pairs:hadoop jar pairs2.jar pairs input output
Stripes:hadoop jar Stripes2.jar Stripes input output

Output Format:
Pairs:removed non characters and empty spaces emits word pair with respective counts.
Stripes:Emits stripes by using mapwritable and emits word as value and all the cooccuring words with counts as value.(By overriding toString() function of mapwritabe).


Part 3 Activity 1:
1.The file "latn.jar" in jars folder finds the occurances of the words with their locations.
2.For this part,the file la.lexicon.csv should be placed in the same path as of latn.jar file.This is placed in input/la.lexicon.
3.The input for this is stored in inputs/latinin and it contains all the latin files.
4.The output for this part is placed in the outputs/output_latin1.

Output Format:
This emits latin word as the key and their positions as values.The position(location) is in the format [docid,chapter,line and position in that line].

Hadoop commands:
hadoop jar latn.jar latn input output


Part 4 Activity 2a:
1.The file latinco.jar finds the cooccurance of the latin words 2 at a time(pairs of words)and their locations.
2.For this part la.lexicon.csv should be placed in the same path/directory of the jar files.
3.The input for this is stored in inputs/latinin.
4.The outputs obtained for this part is placed in outputs/output_latin2.

output Format:
The word pair is emitted as key and the value is the location of the word which is in the format [docid,chapter,line,position in that line].

Hadoop commands:
hadoop jar latinco.jar latinco input output


Part 4 Activity 2b:
1.The file latin3co.jar finds the cooccurance of the latin words triplets and their locations.
2.For this part la.lexicon.csv should be placed in the same path/directory of the jar files.
3.The input for this is stored in inputs/latinin.
4.The outputs obtained for this part is placed in outputs/output_latin3.

output format:
The word triplet is emitted as the key and the locations in the documents as value which is in the format [docid,chapter,line,position in line]

Hadoop commands:
hadoop jar latin3co.jar latin3co input output