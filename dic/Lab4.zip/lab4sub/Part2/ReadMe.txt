lab 4:
Submission:There are 4 folders-> part1,part2,Activity1,Activity2a,Activity2b
Each Folder contains another 4 subfolders -> jar,javacode,inputs,outputs of their respective parts.

Part 2:
1.This part calculates the cooccurance of the words by using two approaches stripes and pairs.
2.part2/jar/pairs2.jar is the jar file to calculate cooccurance of pairs of words using pairs approach taking one total line as scope.
3.part2/jar/Stripes2.jar is the jar file to find cooccurance using stripes approach.
4.The file part2/input/tweets.csv is given as an input for both Stripes and pairs.
5.The outputs I obtained for the pairs and stripes is in the outputs/output_pairs folder and output/output_stripes folder for both tweets and books folder in hadoop.

Hadoop Commands used:
hdfs dfs -put ~/tweets.csv ~/input
Pairs:hadoop jar pairs2.jar pairs input output
Stripes:hadoop jar Stripes2.jar Stripes input output

Output Format:
Pairs: Removed non characters and empty spaces.Key is the wordpair and value is the number of times the wordpair appears with respective counts.
Stripes:Emits stripes by using mapwritable and emits word as Key and all the cooccuring words with counts as value.(By overriding toString() function of mapwritabe).

Output folder:
Output folder contains two different folders stripes and pairs where each folder agains contains two folders books and tweets. I implemented it by using both inputs.