import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.MapWritable;
import java.io.IOException;
import java.util.Set;

public class Stripes{
	public static class MyMapWrite extends MapWritable{
		
	    @Override
	    public String toString() {
	        StringBuilder result = new StringBuilder();
	        Set<Writable> keySet = this.keySet();

	        for (Object key : keySet) {
	            result.append("{" + key.toString() + " = " + this.get(key) + "}");
	        }
	        return result.toString();
	    }
	}
	public static class StripesMapper extends Mapper<LongWritable,Text,Text,MyMapWrite> {
	    private MyMapWrite occurrenceMap = new MyMapWrite();
	    private Text word = new Text();

	    @Override
	    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
	       String[] tokens = value.toString().split("\\s+");
	        if (tokens.length > 1) {
	            for (int i = 0; i < tokens.length; i++) {
	               String wrd= tokens[i].replaceAll("[^a-zA-Z]","");
	            	word.set(wrd);
	                occurrenceMap.clear();

	            for (int j = 0; j < tokens.length; j++) {
	                    if (j == i) continue;
	                    String nbr=tokens[j].replaceAll("\\W", "");
	                    Text neighbor = new Text(nbr);
	                    if(occurrenceMap.containsKey(neighbor)){
	                       IntWritable count = (IntWritable)occurrenceMap.get(neighbor);
	                       count.set(count.get()+1);
	                    }else{
	                        occurrenceMap.put(neighbor,new IntWritable(1));
	                    }
	                }
	              context.write(word,occurrenceMap);
	            }
	        }
	    }
	}

	public static class StripesReducer extends Reducer<Text, MyMapWrite, Text, MyMapWrite> {
	    private MyMapWrite incrementingMap = new MyMapWrite();

	    @Override
	    protected void reduce(Text key, Iterable<MyMapWrite> values, Context context) throws IOException, InterruptedException {
	        incrementingMap.clear();
	        for (MyMapWrite value : values) {
	            addAll(value);
	        }
	        context.write(key, incrementingMap);
	    }
	    @Override
	    public String toString(){
			return null;
	    	
	    }


	    private void addAll(MyMapWrite MyMapWrite) {
	        Set<Writable> keys = MyMapWrite.keySet();
	        for (Writable key : keys) {
	            IntWritable fromCount = (IntWritable) MyMapWrite.get(key);
	            if (incrementingMap.containsKey(key)) {
	                IntWritable count = (IntWritable) incrementingMap.get(key);
	                count.set(count.get() + fromCount.get());
	            } else {
	                incrementingMap.put(key, fromCount);
	            }
	        }
	    }
	}



public static void main(String[] args) throws Exception {
  Configuration conf = new Configuration();
  Job job = Job.getInstance(conf, "Stripes occurance");
  job.setJarByClass(Stripes.class);
  job.setMapperClass(StripesMapper.class);
  job.setCombinerClass(StripesReducer.class);
  job.setReducerClass(StripesReducer.class);
  job.setOutputKeyClass(Text.class);
  job.setOutputValueClass(MyMapWrite.class);
  FileInputFormat.addInputPath(job, new Path(args[0]));
  FileOutputFormat.setOutputPath(job, new Path(args[1]));
  System.exit(job.waitForCompletion(true) ? 0 : 1);
}
}
