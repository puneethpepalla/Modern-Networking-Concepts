lab 4:
Submission:There are 4 different folders for each activity-> part1,part2,Activity 1,Activity2a,Activity2b
Each Folder contains another 4 subfolders -> jar,javacode,inputs,outputs,notebooks of their respective parts.

Part 1:
(The R notebooks for this part are stored in notebooks folder lab4part1 and wordcloud)
1.The first notebook "lab4part1" is the r script for crawling tweets.This generates two csv files tweets.csv and final.csv .The tweets.csv is used later in pairs and stripes part of the lab. 
These files are generated after removing stopwords and cleaning the tweets and are stored into "final.csv".
2.This final.csv is given as input for hadoop WordCount.jar in the jar folder by putting the final.csv in the input folder of hadoop.

Hadoop command: hdfs dfs -put ~/final.csv ~/input

3.Rename the output file from hadoop as "ip" without any extension.(I read the file using read.csv by using "\t" as seperator).
4.This "ip" is given as input to wordcloud.ipynb and it generates the wordcloud.

Commands Used in Hadoop:
hadoop jar WordCount.jar WordCount input output

Output:
The output for the word cloud or tag cloud is already generated in the notebook provided in this folder.

The csv files generated using the first notebook and the file generated using wordcount.jar are placed in output folder of this section.The ip file in the output folder is the output file of the wordcount.jar on tweets.

The input folder also contains the csv and wordcount files because they should be again given as the input to the wordcloud notebook and wordcount.jar files. So I placed the files in both folders.

The output folder also contains two different folders which are the wordcounts for the books folder given in hadoop and the wordcount done on the tweets. These are done while practice.
So I included them as well.

The javacode folder contains the source code for the word count I tweaked it by removing the non-characters and empty spaces during wordcount.

