lab 4:
Submission:There are 4 folders-> part1,part2,Activity 1,Activity2a,Activity2b
Each Folder contains another 4 subfolders -> jar,javacode,inputs,outputs of their respective parts.

Part 4 Activity 2b:
1.The file latin3co.jar finds the cooccurance of the latin words triplets and their locations.
2.For this part la.lexicon.csv should be placed in the same path/directory of the jar files.
3.The input for this is stored in inputs/latinin.
4.The outputs obtained for this part is placed in outputs/output_latin3.

output format:
The word triplet is emitted as the key and the locations in the documents as value which is in the format [docid,chapter,line,position in line]

Hadoop commands:
hadoop jar latin3co.jar latin3co input output

The TimeGraph included here is generated using time calculated by scaling up the documents to a large number both for pairs and triplets. 
and the values for the obtained time is aslo mentioned in the time.csv file.s