import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class latn{

  public static class TokenizerMapper
       extends Mapper<Object, Text, Text, Text>{
 public HashMap<String,ArrayList<String>> mp=new HashMap<String,ArrayList<String>>();
	 
    public void setup(Context context) throws IOException, InterruptedException{
    	 
         BufferedReader br=new BufferedReader(new FileReader("la.lexicon.csv"));
         String line;
         while((line=br.readLine())!=null){
        String[] wrds=line.split(",");
         ArrayList<String> lists=new ArrayList<String>();
         String wrd=wrds[0].toLowerCase();
       if(mp.containsKey(wrd)){
       	  ArrayList<String> al=mp.get(wrd);
       	  al.add(wrds[2].toLowerCase());
       	  mp.put(wrd, al);
         }
         else{
       	lists.add(wrds[2].toLowerCase());  
         mp.put(wrd,lists);
         }
         }
         br.close();
    }
  
    public void map(Object key, Text value, Context context
                    ) throws IOException, InterruptedException {
     String[] itr = value.toString().split(">\\s+");
      if(itr.length==2){
    	String location;
    	String[] itr1=itr[1].split("\\s+"); 
     for(int i=0;i<itr1.length;i++){
    	location="[docid="+itr[0].replaceAll("[^a-zA-Z]","")+" chptr&line="+itr[0].replaceAll("[^\\d.]","")+" pos@line="+(i+1)+"]\t ";
	//location=itr[0];	
	//location=location+" pos@line="+(i+1)+">";    	
	String word=itr1[i];
    	word=word.toLowerCase();
    	word=word.replaceAll("j","i");
    	word=word.replaceAll("v","u");
    	word=word.replaceAll("\\W","");
    	word=word.replaceAll("[^a-zA-Z]","");
    	
    	if(mp.containsKey(word)){
        	context.write(new Text(word), new Text(location));
        	ArrayList<String> als=mp.get(word);
        for(String s:als){
        	context.write(new Text(s), new Text(location));
        }
        }
        else{
        context.write(new Text(word), new Text(location));
        }
        }
      }
    }
  }
  

  public static class IntSumReducer
       extends Reducer<Text,Text,Text,Text> {
    public void reduce(Text key, Iterable<Text> values,
                       Context context
                       ) throws IOException, InterruptedException {
      String res="";
      for (Text val : values) {
    		res=res+val.toString()+" ";
      }
      context.write(key, new Text(res));
    }
  }
  

  public static void main(String[] args) throws Exception {
    Configuration conf = new Configuration();
    
    Job job = Job.getInstance(conf, "latin");
    job.setJarByClass(latn.class);
    job.setMapperClass(TokenizerMapper.class);
    job.setCombinerClass(IntSumReducer.class);
    job.setReducerClass(IntSumReducer.class);
    job.setOutputKeyClass(Text.class);
    job.setOutputValueClass(Text.class);
    FileInputFormat.addInputPath(job, new Path(args[0]));
    FileOutputFormat.setOutputPath(job, new Path(args[1]));
    System.exit(job.waitForCompletion(true) ? 0 : 1);
  }
}
