Lab 4:
Submission:There are 4 folders-> part1,part2,Activity 1,Activity2a,Activity2b
Each Folder contains another 4 subfolders -> jar,javacode,inputs,outputs of their respective parts.

Part 3 Activity 1:
1.The file "latn.jar" in jars folder finds the occurances of the words with their locations.
2.For this part,the file la.lexicon.csv should be placed in the same path as of latn.jar file.This is placed in input/la.lexicon.
3.The input for this is stored in inputs/latinin and it contains all the latin files.
4.The output for this part is placed in the outputs/output_latin1.

Output Format:
This emits latin word as the key and their positions as values.The position(location) is in the format [docid,chapter,line and position in that line].

Hadoop commands:
hadoop jar latn.jar latn input output