Lab 4:
Submission:There are 4 folders-> part1,part2,Activity 1,Activity2a,Activity2b
Each Folder contains another 4 subfolders -> jar,javacode,inputs,outputs of their respective parts.

Part 4 Activity 2a:
1.The file latinco.jar finds the cooccurance of the latin words 2 at a time(pairs of words)and their locations.
2.For this part la.lexicon.csv should be placed in the same path/directory of the jar files.
3.The input for this is stored in inputs/latinin.
4.The outputs obtained for this part is placed in outputs/output_latin2.

output Format:
The word pair is emitted as key and the value is the location of the word which is in the format [docid,chapter,line,position in that line].

Hadoop commands:
hadoop jar latinco.jar latinco input output