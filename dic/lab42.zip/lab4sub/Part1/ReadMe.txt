lab 4:

Submission:There are 4 folders-> part1,part2,Activity 1,Activity2a,Activity2b
Each Folder contains another 4 subfolders -> jar,javacode,inputs,outputs,notebooks of their respective parts.

Part 1:
(The R notebooks for this part are stored in notebooks folder lab4part1 and wordcloud)
1.The notebook "lab4part1" is the r script for crawling tweets.This generates two csv files tweets.csv and final.csv,after removing stopwords and cleaning the tweets the tweets are stored into "final.csv".
2.This final.csv is given as input for hadoop WordCount.jar in the jar/WordCount.jar and rename the output file from hadoop as "ip" without any extension.(I read the file using "\t" as seperator)
3.This "ip" is given as input to wordcloud.ipynb and it generates the wordcloud.


Commands Used in Hadoop:
hadoop jar WordCount.jar WordCount input output
