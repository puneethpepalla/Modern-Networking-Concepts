lab 4:

Submission:There are 4 folders-> part1,part2,Activity 1,Activity2a,Activity2b
Each Folder contains another 4 subfolders -> jar,javacode,inputs,outputs of their respective parts.

Part 2:
1.part1/jar/WordCount.jar is the jar file to perform normal wordcount.
2.part2/jar/pairs2.jar is the jar file to calculate cooccurance of pairs of words using pairs approach taking one total line as scope.
3.part2/jar/Stripes2.jar is the jar file to find cooccurance using stripes approach.
4.The file part2/input/tweets.csv is given as an input for Stripes and pairs.
5.The outputs I obtained for the pairs and stripes is in the outputs/output_pairs folder and output/output_stripes folder for both tweets and books folder in hadoop.

Hadoop Commands used:
Pairs:hadoop jar pairs2.jar pairs input output
Stripes:hadoop jar Stripes2.jar Stripes input output

Output Format:
Pairs:removed non characters and empty spaces emits word pair with respective counts.
Stripes:Emits stripes by using mapwritable and emits word as value and all the cooccuring words with counts as value.(By overriding toString() function of mapwritabe).

